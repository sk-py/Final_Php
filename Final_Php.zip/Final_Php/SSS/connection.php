<?Php
$conn = mysqli_connect("sql305.infinityfree.com", "if0_34970887", "rY0gewybSZE", "if0_34970887_ecom_db"); //  <--------  This connection string is configured according to the database of infinity free server.
define("MAIN_PATH", $_SERVER['DOCUMENT_ROOT']);
define("IMG_PATH", $_SERVER['DOCUMENT_ROOT'] . "/Final_Php/images/");
define("FETCH_PATH", "../images/");
define("USER_IMG_PATH", $_SERVER['DOCUMENT_ROOT'] . "/Final_Php/user_img/");
?>